#include<iostream>
using namespace std;

int main(){

    int num1;
    int s1,s2,s3;

    cout<<"                                                                       WELCOME TO COVID-19 SELF-ASSESSMENT TEST\n here please answer them carefully and correctly and  predict your expsore to \nCovid-19\n\nTo continue with the Test please enter 1 and any other number to exit the programm."<<endl;
    cin>>num1;

    switch (num1)
    {
    case 1:
        cout<<"\n\nDo you have any symptoms of the above:-\n1.Cough and cold\n2.Fever\n3.Breathing problem \n4.Loss of sense and taste\nPress 1 for yes and 2 for no: "<<endl;
        cin>>s1;

        cout<<"\n\nDo you have any symptoms of the above:-\n1.Diabities\n2.Hypertension\n3.Lung disease\n4.Heart Disease\n5.Kidney Disorder\nPress 1 for yes and 2 for no: "<<endl;
        cin>>s2;

        cout<<"\n\nDid you travel internationally in last:-\n1.7 Days\n2.14 Days\n3.28 days\n4.Did'nt travel internationally from last month\nKindly make your selection by entering the sequence number: "<<endl;
        cin>>s3;
    


    if(s1==1 & s2==1 & s3==1){
        cout<<"\nYou are under HIGH RISK. Please isolate your self and have your covid-19 test from a hospital as soon as possible.\n"<<endl;
    }

    if(s1==1 & s2==1 & s3==2){
         cout<<"\nYou are under HIGH RISK. Please isolate your self and have your covid-19 test from a hospital as soon as possible.\n"<<endl;
    }

    if(s1==1 & s2==1 & s3==3){
        cout<<"\nYou are under HIGH RISK. Please isolate your self and have your covid-19 test from a hospital as soon as possible.\n"<<endl;
    }

    if(s1==1 & s2==1 & s3==4){
        cout<<"\nYou are under MODERATE RISK. Please isolate your self so that we can prevent the spread of this virus.\n"<<endl;
    }
    if(s1==1 & s2==2 & s3==1){
        cout<<"\nYou are under HIGH RISK. Please isolate your self so that we can prevent the spread of this virus.\n"<<endl;
    }
    if(s1==1 & s2==2 & s3==2){
        cout<<"\nYou are under HIGH RISK. Please isolate your self so that we can prevent the spread of this virus.\n"<<endl;
    }
    if(s1==1 & s2==2 & s3==3){
        cout<<"\nYou are under MODERATE RISK. Please isolate your self so that we can prevent the spread of this virus.\n"<<endl;
    }
    if(s1==1 & s2==2 & s3==4){
        cout<<"\nYou are under LOW RISK. But still you should isolate yourself so that together we can prevent the spread of this virus.\n"<<endl;
    }
    if(s1==2 & s2==1 & s3==1){
        cout<<"\nYou are under HIGH RISK. Please isolate your self so that we can prevent the spread of this virus.\n"<<endl;
    }
    if(s1==2 & s2==1 & s3==2){
        cout<<"\nYou are under MODERATE RISK. Please isolate your self so that we can prevent the spread of this virus.\n"<<endl;
    }
    if(s1==2 & s2==1 & s3==3){
        cout<<"\nYou are under MODERATE RISK. Please isolate your self so that we can prevent the spread of this virus.\n"<<endl;
    }
    if(s1==2 & s2==1 & s3==4){
        cout<<"\nYou are under LOW RISK. But still you should isolate yourself so that together we can prevent the spread of ths virus.\n"<<endl;
    }
    if(s1==2 & s2==2 & s3==1){
        cout<<"\nYou are under HIGH RISK. Please isolate your self so that we can prevent the spread of this virus.\n"<<endl;
    }
    if(s1==2 & s2==2 & s3==2){
        cout<<"\nYou are under MODERATE RISK. Please isolate your self so that we can prevent the spread of this virus.\n"<<endl;
    }
    if(s1==2 & s2==2 & s3==3){
        cout<<"\nYou are under MODERATE RISK. Please isolate your self so that we can prevent the spread of this virus.\n"<<endl;
    }
    if(s1==2 & s2==2 & s3==4){
        cout<<"\nYou are under LOW RISK. But still you should isolate yourself so that together we can prevent the spread of ths virus.\n"<<endl;
    }

    if(s1>2 || s2>2 || s3>4){
        cout<<"\nINVALID INPUT!!! Please give a Valid Input.\n"<<endl;
    }
        break;


    
    default:
        cout<<"Thanks for giving your time. Do visit us again!!!!!!\n"<<endl;
        break;
    }
    return 0;
}
